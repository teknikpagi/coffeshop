# Pembuatan website Landing Page yang sangat sederhana

Belajar membuat design yang sangat sederhana dan mencoba mengasah tentang CSS Flexbox dan CSS Grid.


<a href="https://mfebriann.github.io/DrinkingCoffee/"> Demo Website </a>
